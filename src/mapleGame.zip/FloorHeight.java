package mapleGame;

public interface FloorHeight {

   int floor1 = 470;
   int floor2 = 328;
   int floor3 = 183;
   int floor4 = 38;
   int floor5 = 10;

}